
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Metromalls</title>

<link rel="stylesheet" href="assets/css/style.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="Bitter Mobile Template">
<meta name="keywords" content="bootstrap, mobile template, bootstrap 4, mobile, html, responsive" />
<style>
.form-control{box-shadow:none; border-bottom:#ccc solid 1px; height:26px; margin-bottom:3px;}
.form-group{margin-bottom:0px;}
.form-group.floating>label {
    bottom: 34px;
    left: 8px;
    position: relative;
    background-color: white;
    padding: 0px 5px 0px 5px;
    font-size: 1.1em;
    transition: 0.1s;
    pointer-events: none;
    font-weight: 500 !important;
    transform-origin: bottom left;
}

.form-control.floating:focus~label{
    transform: translate(1px,-85%) scale(0.80);
    opacity: .8;
    color: #005ebf;
}

.form-control.floating:valid~label{
    transform-origin: bottom left;
    transform: translate(1px,-110%) scale(0.80);
    opacity: .8;
}
#alert .modal-dialog{padding:20px; margin-top:130px;}
#confirm .modal-dialog{padding:0px; margin-top:130px;}
.btn-sm {
    height: 26px;
    padding: 0px 12px;
}
</style>
</head>

<body>
<!-- Page loading -->
<div class="loading" id="loading">
  <div class="spinner-grow"></div>
</div>
<!-- * Page loading --> 

<!-- App Header -->
<div class="appHeader1"       style=" background: linear-gradient(90deg, #004D40 37%, #004D40 100%);">
  <div class="left"> <a href="#" onClick="goBack();" class="icon goBack"> <i class="icon ion-md-arrow-back"></i> </a>
    <div class="pageTitle">Envelope</div>
  </div>
</div>
<!-- searchBox --> 

<!-- * searchBox --> 
<!-- * App Header --> 

<!-- App Capsule -->
<div id="appCapsule" class="pb-2">
  <div class="appContent1 pb-5">
    <form action="#" method="post" id="envelopeform">
      
      <div class="form-group floating mt-3">
<input hidden type="text" class="form-control floating" id="name" name="name" required value="1111">
<label hidden  for="name">Actual Name<i class="text-danger">*</i></label>
</div>

<div class="form-group floating">
<input hidden  type="number" class="form-control floating" id="mobile" name="mobile" maxlength="10" required value="9876543210">
<label hidden  for="mobile">Mobile<i class="text-danger">*</i></label>
</div>
<div class="form-group floating">
<input hidden  type="text" class="form-control floating" id="email" name="email" required value="abh@gmail.com">
<label hidden  for="email">Email id<i class="text-danger">*</i></label>
</div>
<div hidden  class="btn-group btn-group-toggle mt-n1" data-toggle="buttons">
                        <label class="btn btn-outline-warning active">
                            <input type="radio" name="optionsname" id="option1" value="100" checked>
                            <i class="icon"><i class="fa fa-rupee"></i></i>&nbsp;
                            5.00
                        </label>
                        
                    </div>
<input type="hidden" name="action" id="action" value="envelope">
<input type="hidden" name="userid" id="userid" value="36">
<input type="hidden" name="editid" value="">
<div class="text-center mt-1">
        <button type="submit" class="btn btn-primary" style="width:264px;"> Submit </button>
      </div>
    </form>
  </div>
</div>
<!-- appCapsule -->

<div hidden class="appBottomMenu">
  <div class="hover-fx item "> <a href="index">
    <p> <i class="res ri-home-8-line " ></i> <span style="font-family: 'Rajdhani', sans-serif;">Home</span> </p>
    </a> </div>
  <div class="hover-fx item "> <a href="search">
    <p> <i class="res ri-wallet-3-line "></i> <span style="font-family: 'Rajdhani', sans-serif;">Search</span> </p>
    </a> </div>
       <div class="hover-fx item "> <a href="win">
    <p> <i class="ri-layout-grid-fill text-danger"></i> <span style="font-family: 'Rajdhani', sans-serif;">Win</span> </p>
    </a> </div>
    <div class="hover-fx item "> <a href="my" class="icon toggleSidebar">
    <p> <i class="res ri-user-heart-line"></i><span  style="font-family: 'Rajdhani', sans-serif;">My </span> </p>
    </a> </div>
    </div>

<style> 
.res{
    color: #9E9E9E;
   
}

.spinner-border{
 		display: inline-block;
	width: $radius;
	height: $radius;
	border-radius: 50%;
	margin: 0 4px;

}

.spinner-border1{
 		display: inline-block;
	width: $radius;
	height: $radius;
	border-radius: 50%;
	margin: 0 4px;
	border: $border solid green;
    
}


.spinner-border2{
    width: 170px;
		display: inline-block;
	width: $radius;
	height: $radius;
	border-radius: 50%;
	margin: 1 4px;
	border: $border solid pink;
    
}
.res:hover{
     cursor: pointer;
  background: #5D9CF3;
  color: #FF4081
;
  transition: background-color 20000.9s ease;
}

.hover-fx{
     cursor: pointer;
  background: white;
  color: #FF4081
;
  transition: background-color 20000.9s ease;
    
}
</style>

<link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@700&display=swap" rel="stylesheet"><div id="alert" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body" id="alertmessage"> </div>
      <div class="text-center pb-1">
    <a type="button" class="text-info" data-dismiss="modal">OK</a>
    </div> 
    </div>
  </div>
</div>
<div id="confirm" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
        
         <form action="#" method="post" id="envelopeform">
      
      <div class="form-group floating mt-3">
<input type="text" class="form-control floating" id="name" name="name" required value="">
<label for="name">Actual Name<i class="text-danger">*</i></label>
</div>

<div class="form-group floating">
<input type="number" class="form-control floating" id="mobile" name="mobile" maxlength="10" required value="">
<label for="mobile">Mobile<i class="text-danger">*</i></label>
</div>
<div class="form-group floating">
<input type="text" class="form-control floating" id="email" name="email" required value="">
<label for="email">Email id<i class="text-danger">*</i></label>
</div>
<div hidden  class="btn-group btn-group-toggle mt-n1" data-toggle="buttons">
                        <label class="btn btn-outline-warning active">
                            <input type="radio" name="optionsname" id="option1" value="100" checked>
                            <i class="icon"><i class="fa fa-rupee"></i></i>&nbsp;
                            5.00
                        </label>
                        
                    </div>
<input type="hidden" name="action" id="action" value="envelope">
<input type="hidden" name="userid" id="userid" value="36">
<input type="hidden" name="editid" value="">
<div class="text-center mt-1">
        <button type="submit" class="btn btn-primary" style="width:264px;"> Submit </button>
      </div>
    </form>
        
      <div class="modal-body"> Are you sure you want to collect envelope ?</div>
      <input type="hidden" id="deleteid" name="deleteid" value="">
      <div class=" text-center pb-1">
    <a type="button" class="btn btn-sm bg-danger text-light" onClick="submitenvelope();">YES</a>
    <a type="button" class="btn btn-sm btn-primary text-light" data-dismiss="modal">NO</a>
    </div> 
    </div>
  </div>
</div>
<!-- Jquery --> 
<script src="assets/js/lib/jquery-3.4.1.min.js"></script> 
<!-- Bootstrap--> 
<script src="assets/js/lib/popper.min.js"></script> 
<script src="assets/js/lib/bootstrap.min.js"></script> 
<!-- Owl Carousel --> 
<script src="assets/js/plugins/owl.carousel.min.js"></script> 
<!-- Main Js File --> 
<script src="assets/js/app.js"></script>
<script src="assets/js/envelope.js"></script>
</body>
</html>