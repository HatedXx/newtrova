const refer_code_link=()=>{var url=new URL(window.location.href);var c=url.searchParams.get("refer_code");if(c!=null){refer_code.value=c}}
registerSubmit.addEventListener("click",()=>{if(mobile.value.length<10||password.value.length<3||withdraw_password.value.length<3||otp.value.length<3||refer_code.value.length<3){error.style.display='block';error_text.innerText="please fill all details correctly!";setTimeout(()=>{error.style.display='none';},2000);return}
if(document.getElementById('privacy_check').classList.contains("uni-checkbox-input-checked")){const info={mobile:mobile.value.replace('+',''),password:password.value,refer_code:refer_code.value,withdraw_pass:withdraw_password.value,otp:otp.value}
fetch("/api/post/register",{method:"POST",body:JSON.stringify(info),headers:{"Content-Type":"application/json"}}).then(res=>res.json()).then(data=>{if(data.status=="error"){error.style.display='flex'
error_text.innerText=data.message
setTimeout(()=>{error.style.display='none'},2000);}else{error.style.display='none'
window.location.replace("/login")}})}else{error.style.display='flex'
error_text.innerText="Please Check agree box"
setTimeout(()=>{error.style.display='none'},2000);}})
const otp_sender=()=>{if(mobile.value.length==10){otpSection.innerHTML=`<uni-button data-v-000e2385="" id="otpSend" disabled="disabled" class="default" style="height:auto">Wait 60</uni-button>`
let i=60
let otp_text=setInterval(()=>{i--
otpSend.innerText=`Wait ${i}`
if(i==0){otpSend.innerText=`OTP`
otpSnd.addAttribute('onclick','otp_sender()')
otpSend.removeAttribute("disabled")
clearInterval(otp_text)}},1000);fetch("/api/post/send_otp",{method:"POST",body:JSON.stringify({mobile:mobile.value}),headers:{"Content-Type":"application/json"}}).then(res=>res.json()).then(data=>{if(data.status==0){error.style.display='flex'
error_text.innerText=data.message}else{error.style.display='flex'
error_text.innerText="Otp sent"
setTimeout(()=>{error.style.display='none'},2000);}})}else{error.style.display="block"
error_text.innerText="Mobile number required"
setTimeout(()=>{error.style.display="none"},2000);}}
show_hide.addEventListener('click',()=>{if(withdraw_password.getAttribute("type")=="password"){show_hide.innerText=''
withdraw_password.setAttribute("type","text")}else{show_hide.innerText=''
withdraw_password.setAttribute("type","password")}})
refer_code_link()