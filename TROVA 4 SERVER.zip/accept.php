<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["adloggedin"]) || $_SESSION["adloggedin"] !== true){
    header("location: adlogin");
    exit;
}
require_once "config.php";
  $username=$_GET['un'];
  $amount=$_GET['am'];
  $utr=$_GET['utr'];
  $first=0;


$opt="SELECT SUM(recharge) as total FROM `recharge` WHERE username='$username' AND status='Success'";
$optres=$conn->query($opt);
$sum= mysqli_fetch_assoc($optres);
if($sum['total']=="" or $sum['total']=="0"){
   
         
                     if($amount>=500 && $amount<1000){
             $bonus=150;
         }elseif($amount>=1000 && $amount<3000){
             $bonus=200;
         }elseif($amount>=3000 && $amount<4000){
             $bonus=400;
         }elseif($amount>=4000 && $amount<5000){
             $bonus=500;
         }elseif($amount>=5000 && $amount<10000){
             $bonus=600;
         }elseif($amount>=10000){
             $bonus=1100;
         }
            
        
   
     
          
    $win="select refcode FROM `users` WHERE  username='$username' ";
$result3 =$conn->query($win);
$row3 = mysqli_fetch_assoc($result3);
$refcode=$row3['refcode'];
$adb="UPDATE users SET balance= balance +$bonus WHERE usercode='$refcode'";
$conn->query($adb);
$addbrec="INSERT INTO bonus (giver,usercode,amount,level) VALUES ('$username','$refcode','$bonus','6')";
$conn->query($addbrec);
    
}

$addwin00="UPDATE recharge SET status='Success' WHERE username='$username' AND recharge='$amount' AND utr='$utr'";
$conn->query($addwin00);

if($conn->query($addwin00)){
    $first=0;
    
    $addwin0="UPDATE users SET balance= balance +($amount+$first) WHERE username='$username'";
   
    if($conn->query($addwin0)){
        header("location: rechargeRequests");
    }
}else{
    echo"FAILED";
}
?>