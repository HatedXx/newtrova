<?php
/*
This file contains database config.phpuration assuming you are running mysql using user "root" and password ""
*/

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'apnascho_wp');
define('DB_PASSWORD', '9660007766raj@');
define('DB_NAME', 'apnascho_wp');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

 date_default_timezone_set('Asia/Calcutta');
    $today = date("F j, Y, g:i a"); 
//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
    Echo"Fail";
}

?>