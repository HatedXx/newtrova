<?php
ob_start();
session_start();
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php include 'head.php' ?>
  <link rel="stylesheet" href="assets/css/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta name="description" content="">
  <meta name="keywords" content="" />
  <style>
    .otpbtn {
      background: #f5f5f5;
      margin: 0;
      border-radius: 0px;
    }
    #login_mobile_text {
    position: absolute;
    top: 12px;
    font-size: 18px;
    left: 31px;
}


.container {
  position: relative;
  width: 100%;
  max-width: 100%;
}

.container img {
  width: 100%;
  height: 100%;
}

.container .btn {
  position: absolute;
  top: 62%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color: #555;
  color: white;
  font-size: 16px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}

.container .btn:hover {
  background-color: black;
}
  </style>

</head>

<body>
  <?php include("include/connection.php"); ?>

  <!-- Page loading -->
  <!--<?php include('loading.php'); ?>-->
  <!-- * Page loading -->
  <!-- App Header -->
  <div class="appHeader1" style="background-color:  #009688!important;">
    <div class="left">
      <a href="#" onClick=";" class="k">
        <i class="icon ion-md-arrow-back"></i>
      </a>
      
    </div>


  </div>
  <!-- * App Header -->
  <!-- App Capsule -->
  <div id="appCapsule">
    <div class="appContent1 mb-2">

      <form action="dosignin.php" method="post" class="card-body" autocomplete="off">
        <div class="row ">

          <div class="col-12">
            <div class="">
                <div class="container">
              <img src="redin.jpg" alt="Snow" hight="100%" width="100%">
             <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Claim HERE</button>
            </div>
            
     <?php
     
     ?>       
            
            
            
             


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
          <form action="dosignin.php" method="post" >
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Claim Here</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Enter mobile Number</label>
            <input type="text" class="form-control" name="mobile" id="mobile">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Red Envelopee-Code</label>
            <input type="text" class="form-control" name="envcode" id="envcode" value="<?php echo @$_GET['reward'];?>" readonly>
          </div>
          <div>
              <button type="sumbit" class="btn btn-primary">SUMBIT</button>
          </div>
          <!--<div class="form-group">-->
          <!--  <label for="message-text" class="col-form-label">Amount:</label>-->
          <!--  <textarea class="form-control" id="message-text"></textarea>-->
          <!--</div>-->
    
      </div>
          </form>
      <!--<div class="modal-footer">-->
      <!--  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
      <!--  <button type="button" class="btn btn-primary">SUMBIT</button>-->
      <!--</div>-->
    </div>
  </div>
</div>
            </div>
          </div>

          
  <!-- appCapsule -->

  <?php include("include/footer.php"); ?>
  <div id="registerthanksPopup" class="modal fade" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content ">
        <div class="modal-body">
          <div class="text-center">
            <h5>Success !</h5>

            <div class="text-center">
              <button type="button" class="btn btn-sm btn-primary" onClick="window.location='';">OK</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 
  <div id="otpform" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content ">
        <div class="modal-body">
          <button type="button" id="otpclose" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
          <p><strong>Plese Enter OTP</strong></p>
          <div class="pt-2">
            <form action="#" method="post" id="otpsubmitForm">
              <input type="text" id="otp" name="otp" class="form-control" placeholder="Enter OTP" onKeyPress="return isNumber(event)">
              <input type="hidden" name="type" id="type" value="otpval">
              <div class="text-center mt-3">
                <button type="submit" class="btn btn-primary" style="width:264px;"> Submit OTP </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap-->
  <script src="assets/js/lib/popper.min.js"></script>
  <script src="assets/js/lib/bootstrap.min.js"></script>
  <!-- Owl Carousel -->
  <script src="assets/js/plugins/owl.carousel.min.js"></script>
  <!-- Main Js File -->
  <script src="assets/js/app.js"></script>
  <script src="assets/js/jquery.validate.min.js"></script>
  <script src="assets/js/account.js"></script>

  <script>
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) {
      var sParameterName = sURLVariables[i].split('=');
      $("#rcode").val(sParameterName[1])
    }
  </script>
</body>

</html>